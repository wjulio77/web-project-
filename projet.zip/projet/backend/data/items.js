// backend/data/items.js
// Simple array of dish objects used by the API.
const items = [
  {
    title: "Duck Confit Signature",
    desc: "Slow-cooked duck leg confit with crispy skin, served with a light thyme jus and creamy parsnip purée.",
    img: "../assets/images/specialite-perigord-poulet-aux-pommes-terre-sarlat.jpg"
  },
  {
    title: "Beef Bourguignon Évolution",
    desc: "Slow-braised beef in Burgundy wine with carrots, onions, and mushrooms, finished with a touch of truffle.",
    img: "../assets/images/Boeuf-Bourguignon.jpg"
  },
  {
    title: "Alpine Raclette Revival",
    desc: "Melted Alpine cheese served over roasted baby potatoes with pickles, charcuterie, and herb-infused oil.",
    img: "../assets/images/raclette-fromage.jpg"
  },
  {
    title: "Foie Gras Brûlé",
    desc: "Lightly caramelized foie gras for a contrast of crisp top and silky texture, served with a sweet-acidic garnish.",
    img: "../assets/images/creme_brulee_au_foie_gras.jpg"
  }
];

module.exports = items; // Export array for use in server.js
