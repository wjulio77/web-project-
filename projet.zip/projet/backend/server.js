// backend/server.js
// Express API for the dishes carousel.

const express = require('express');      // Import Express framework
const cors = require('cors');            // Allow cross-origin requests
const items = require('./data/items');   // Import our dishes array

const app = express();
app.use(cors());                         // Enable CORS for all origins (frontend on another port)
app.use(express.json());                 // Parse JSON bodies (not required but safe)

let index = 0;                           // Current item index in memory

// GET /item -> return current item
app.get('/item', (req, res) => {
  res.json({
    index,
    item: items[index],
    total: items.length
  });
});

// GET /item/next -> move to next item, wrap at end
app.get('/item/next', (req, res) => {
  index = (index + 1) % items.length;    // Circular increment
  res.json({
    index,
    item: items[index],
    total: items.length
  });
});

// GET /item/prev -> move to previous item, wrap at start
app.get('/item/prev', (req, res) => {
  index = (index - 1 + items.length) % items.length; // Circular decrement
  res.json({
    index,
    item: items[index],
    total: items.length
  });
});

// GET /item/:id -> optional, jump to a specific index
app.get('/item/:id', (req, res) => {
  const id = parseInt(req.params.id, 10); // Convert URL param to number

  if (Number.isNaN(id) || id < 0 || id >= items.length) {
    // Invalid index -> 404 error
    return res.status(404).json({ error: 'Item not found' });
  }

  index = id; // Update current index
  res.json({
    index,
    item: items[index],
    total: items.length
  });
});

const PORT = process.env.PORT || 3000;   // Default port is 3000

app.listen(PORT, () => {
  console.log(`Backend server running on http://localhost:${PORT}`);
});
