# Backend API – French Dishes Project

This folder contains the backend part of the assignment:  
a simple Express API that serves a list of French dishes and provides next/previous navigation.

## Files

- `data/items.js` – JS array of item objects (`title`, `desc`, `img`)
- `server.js` – Express server with API endpoints
- `package.json` – dependencies and npm scripts
- `.gitignore` – files and folders ignored by Git

## Installation (local)

1. Open a terminal in the `backend` folder:
   ```bash
   cd backend
