// Connect frontend to backend API instead of using local data.js.
// Backend runs at: http://localhost:3000

const API_URL = "http://localhost:3000";

// Select HTML elements
const titleEl = document.getElementById("title");
const imageEl = document.getElementById("image");
const descEl = document.getElementById("desc");
const nextBtn = document.getElementById("next");
const prevBtn = document.getElementById("prev");

// Function that loads an item from a given API endpoint
async function loadItem(endpoint = "/item") {
  try {
    const response = await fetch(API_URL + endpoint);
    const data = await response.json();

    // Update the page with the data returned by the backend
    titleEl.textContent = data.item.title;
    descEl.textContent = data.item.desc;
    imageEl.src = data.item.img;
  } catch (error) {
    console.error("Failed to load item:", error);
  }
}

// Button listeners
nextBtn.addEventListener("click", () => loadItem("/item/next"));
prevBtn.addEventListener("click", () => loadItem("/item/prev"));

// Load first item on page load
loadItem();
